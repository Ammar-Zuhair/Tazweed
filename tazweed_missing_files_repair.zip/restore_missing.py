"""Restore verified missing Tazweed assets without overwriting existing work.
Python 3.9+; standard library only. Run from the extracted repair bundle.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile

HERE = Path(__file__).resolve().parent

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def safe_path(root, relative):
    part = PurePosixPath(relative)
    if part.is_absolute() or '..' in part.parts or '\\' in relative:
        raise ValueError('Unsafe path: ' + relative)
    path = root.joinpath(*part.parts)
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        raise ValueError('Path escapes target directory: ' + relative)
    return path

def matches(path, record):
    return path.is_file() and path.stat().st_size == record['bytes'] and sha(path) == record['sha256']

def atomic_create(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.tazweed-restore-', dir=str(target.parent))
    temporary = Path(name)
    try:
        with os.fdopen(fd, 'wb') as out, source.open('rb') as incoming:
            for chunk in iter(lambda: incoming.read(1024 * 1024), b''):
                out.write(chunk)
            out.flush()
            os.fsync(out.fileno())
        if sha(temporary) != sha(source):
            raise ValueError('Temporary copy failed verification')
        # An exclusive atomic hard-link prevents overwriting a file created concurrently.
        try:
            os.link(temporary, target)
        except FileExistsError:
            return False
        return True
    finally:
        temporary.unlink(missing_ok=True)

def verify_full(target, source_manifest):
    verified = []
    relocated = []
    missing = []
    modified = []
    for entry in source_manifest['files']:
        relative = entry['path']
        canonical = safe_path(target, relative)
        candidates = [canonical]
        if relative in ('customer-app/media/intro-light.mp4', 'customer-app/media/intro-dark.mp4'):
            candidates += [safe_path(target, relative.replace('/media/', '/video/')),
                           safe_path(target, Path(relative).name)]
        found = next((p for p in candidates if matches(p, entry)), None)
        if found:
            verified.append(relative)
            if found != canonical:
                relocated.append({'expected': relative, 'found': str(found.relative_to(target))})
        elif any(p.exists() for p in candidates):
            modified.append(relative)
        else:
            missing.append(relative)
    return {'manifest_total': len(source_manifest['files']), 'verified_files': len(verified),
            'relocated_verified_videos': relocated, 'missing_files': missing,
            'existing_different_files_preserved': modified}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', required=True, help='Existing repository root, e.g. /workspace')
    parser.add_argument('--restore', action='store_true', help='Create missing files only; otherwise read-only')
    args = parser.parse_args()
    target = Path(args.target).resolve(strict=True)
    if not target.is_dir():
        parser.error('--target must be an existing directory')
    repair = json.loads((HERE / 'REPAIR_MANIFEST.json').read_text(encoding='utf-8'))
    original = json.loads((HERE / 'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    # Complete preflight before creating any target file.
    for entry in repair['files']:
        source = safe_path(HERE, entry['path'])
        safe_path(target, entry['path'])
        if not matches(source, entry):
            raise ValueError('Repair source missing or corrupt: ' + entry['path'])
    restored = []
    preserved = []
    if args.restore:
        for entry in repair['files']:
            destination = safe_path(target, entry['path'])
            if destination.exists():
                preserved.append(entry['path'])
                continue
            if atomic_create(safe_path(HERE, entry['path']), destination):
                restored.append(entry['path'])
            else:
                preserved.append(entry['path'])
    report = {'mode': 'restore_missing_only' if args.restore else 'check_only',
              'target': str(target), 'repair_payload_verified': len(repair['files']),
              'restored_files': restored, 'existing_files_preserved': preserved,
              'full_verification': verify_full(target, original)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if report['full_verification']['missing_files'] and args.restore else 0

if __name__ == '__main__':
    raise SystemExit(main())
